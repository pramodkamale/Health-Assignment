package com.kratin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kratin.dto.ErrorResponse;
import com.kratin.pojos.AppUser;
import com.kratin.service.UserServiceImpl;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class SignUpController 
{
	public SignUpController() {
		System.out.println("Inside user Controller");
	}

	@Autowired
	private UserServiceImpl userService;

	@PostMapping("/signup")
	public ResponseEntity<?> addNewUser(@RequestBody AppUser transientUser)
	{
		System.out.println("Inside addNewUser()--SignUpController");
		System.out.println(transientUser);
		try
		{
			return new ResponseEntity<>(userService.addUser(transientUser),HttpStatus.CREATED);
			
		}catch(RuntimeException e)
		{
			System.out.println("Error in addNewUser() : "+e);
			//e.printStackTrace();
			return new ResponseEntity<>(new ErrorResponse("Adding user failed", e.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	    
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> logInUser(@RequestBody AppUser transientUser)
	{
		System.out.println("Inside loginUser()--SignUpController");
		System.out.println(transientUser);
		try
		{
			AppUser user = userService.logIn(transientUser);
			if(user !=null) {
				return new ResponseEntity<>(user,HttpStatus.OK);
			}
		return new ResponseEntity<>(new ErrorResponse("Wrong Credentials",""),HttpStatus.NOT_ACCEPTABLE);
			
		}catch(RuntimeException e)
		{
			System.out.println("Error in addNewUser() : "+e);
			//e.printStackTrace();
			return new ResponseEntity<>(new ErrorResponse("Adding user failed", e.getMessage()),HttpStatus.INTERNAL_SERVER_ERROR);
		}
	    
	}
}
