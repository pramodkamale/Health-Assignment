package com.kratin.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.kratin.dto.ErrorResponse;
import com.kratin.pojos.AppUser;
import com.kratin.pojos.HeartRateRequest;
import com.kratin.service.IUserService.HeartRateService;
import com.kratin.service.UserServiceImpl;

@RestController
@RequestMapping("/users")
@CrossOrigin
public class UserController {
	public UserController() {
		System.out.println("Inside user Controller");
	}

	@Autowired
	private UserServiceImpl userService;


	@GetMapping("/profile/{userId}")
	public ResponseEntity<?> fetchUserProfile(@PathVariable int userId) {
		System.out.println("Inside fetchUserProfile()--UserController " + userId);
		try {
			return new ResponseEntity<>(userService.getProfileByUserId(userId), HttpStatus.OK);
		} catch (RuntimeException e) {
			System.out.println("Error in fetchUserProfile() : " + e);
			// e.printStackTrace();
			return new ResponseEntity<>(new ErrorResponse("Fetching UserProfile failed", e.getMessage()),
					HttpStatus.BAD_REQUEST);
		}
	}

	@PutMapping("/{userId}")
	public ResponseEntity<?> updateUserProfile(@RequestBody AppUser updatedUserProfile, @PathVariable int userId) {
		System.out.println("Inside updateUserProfile()--UserController " + userId);
		try {
			return new ResponseEntity<>(userService.updateUserProfileDetails(updatedUserProfile), HttpStatus.OK);
		} catch (RuntimeException e) {
			System.out.println("Error in updateUserProfile() : " + e);
			// e.printStackTrace();
			return new ResponseEntity<>(new ErrorResponse("Updating User Profile failed", e.getMessage()),
					HttpStatus.BAD_REQUEST);
		}

	}
	
	@RestController
	@RequestMapping("/api/heart-rate")
	public class HeartRateController {

	    private final HeartRateService heartRateService;

	    public HeartRateController(HeartRateService heartRateService) {
	        this.heartRateService = heartRateService;
	    }

	    @PostMapping
	    public ResponseEntity<String> checkHeartRate(@RequestBody HeartRateRequest heartRateRequest) {
	        boolean isWithinRange = heartRateService.isHeartRateWithinRange(heartRateRequest.getHeartRate());

	        if (isWithinRange) {
	            return ResponseEntity.ok("Heart rate is within the range.");
	        } else {
	            return ResponseEntity.badRequest().body("Heart rate is not within the range.");
	        }
	    }
	}



}
