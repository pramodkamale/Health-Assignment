package com.kratin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineBookStoreNoSecApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineBookStoreNoSecApplication.class, args);
	}

}
