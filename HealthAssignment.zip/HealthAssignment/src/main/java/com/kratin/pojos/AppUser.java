package com.kratin.pojos;

import java.util.Collections;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="users")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(exclude = "password")
public class AppUser {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Integer userId;
	
	@Column(name = "user_name", length = 50, nullable = false)
	private String userName;
	
	@Column(length = 50,nullable = false,unique = true)
	private String email;
	
	//@JsonProperty(access = Access.WRITE_ONLY)
	@Column(length = 50,nullable = false)
	private String password;
	
	@Column(length = 15,nullable = false)
	private String mobile;
	
	@Column(length = 15,nullable = false)
	private Integer age;
	
	@Column(length = 15,nullable = false)
	private Integer bpm;
	
}




