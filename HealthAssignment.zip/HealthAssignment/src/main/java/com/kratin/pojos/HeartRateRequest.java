package com.kratin.pojos;

public class HeartRateRequest {
    private int heartRate;

    // Getter and setter

    public int getHeartRate() {
        return heartRate;
    }

    public void setHeartRate(int heartRate) {
        this.heartRate = heartRate;
    }
}
