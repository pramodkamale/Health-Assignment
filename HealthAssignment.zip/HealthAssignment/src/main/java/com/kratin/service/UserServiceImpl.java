package com.kratin.service;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kratin.custom_exception.CustomException;
import com.kratin.daos.AppUserDao;
import com.kratin.pojos.AppUser;


@Service
@Transactional
public class UserServiceImpl implements IUserService {


	@Autowired
	private AppUserDao userDao;


	

	@Override
	public AppUser getProfileByUserId(int userId) {
		System.out.println("Inside getProfileByUserId()--in UserServiceImpl");
		return userDao.findById(userId).orElseThrow(() -> new CustomException("User by specified id not found"));
	}

	@Override
	public AppUser updateUserProfileDetails(AppUser updatedUserProfile) {
		System.out.println("Inside updateUserProfileDetails()--in UserServiceImpl");
		return userDao.save(updatedUserProfile);
	}


	@Override
	public AppUser addUser(AppUser userToBeAdded) {
		System.out.println("Inside addBook()--in AdminServiceImpl");
		return userDao.save(userToBeAdded);
	}

	@Override
	public AppUser logIn(AppUser userToBeChecked) {
		System.out.println("Inside logIn()--in AdminServiceImpl");
		AppUser fetchedUser = userDao.findByEmail(userToBeChecked.getEmail());
		if (fetchedUser.getPassword().equals(userToBeChecked.getPassword())) {
			return fetchedUser;
		}
		return null;
	}
	
	@Service
	public class HeartRateServiceImpl implements HeartRateService {

	    private static final int MIN_HEART_RATE = 70;
	    private static final int MAX_HEART_RATE = 120;

	    @Override
	    public boolean isHeartRateWithinRange(int heartRate) {
	        return heartRate >= MIN_HEART_RATE && heartRate <= MAX_HEART_RATE;
	    }
	}


}