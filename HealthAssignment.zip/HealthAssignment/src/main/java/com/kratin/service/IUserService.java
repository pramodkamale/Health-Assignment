package com.kratin.service;


import com.kratin.pojos.AppUser;


public interface IUserService {

	public AppUser getProfileByUserId(int userId);

	public AppUser updateUserProfileDetails(AppUser updatedUserProfile);


	// sign
	public AppUser addUser(AppUser userToBeAdded);

	public AppUser logIn(AppUser userToBeChecked);

	public interface HeartRateService {
	    boolean isHeartRateWithinRange(int heartRate);
	}


}
